package org.tygus.suslik.language

/**
  * @author Ilya Sergey
  */

trait PrettyPrinting {
  def pp : String = toString
}
