package org.tygus.suslik

/**
  * @author Ilya Sergey
  */

package object language {

  type Ident = String

}
