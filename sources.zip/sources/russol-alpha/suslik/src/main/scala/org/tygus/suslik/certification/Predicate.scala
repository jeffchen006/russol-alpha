package org.tygus.suslik.certification

import org.tygus.suslik.language.PrettyPrinting

trait Predicate extends PrettyPrinting {
  val name: String
}